/*
 * TMR1_private.h
 *
  * Created: 1/12/2024
  *  Author:Ahmed Yasser
 */

#ifndef TMR1_PRIVATE_H_
#define TMR1_PRIVATE_H_



#endif /* TMR1_PRIVATE_H_ */
