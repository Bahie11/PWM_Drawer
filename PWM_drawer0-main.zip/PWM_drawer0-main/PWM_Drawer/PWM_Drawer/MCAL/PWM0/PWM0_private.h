/*
 * ATmega32A_Config.h
 *
 * Created: 1/12/2024
 *  Author:Ahmed Yasser
 */ 


#ifndef MCAL_PWM0_INC_PWM0_PRIVATE_H_
#define MCAL_PWM0_INC_PWM0_PRIVATE_H_


#define PWM0_NONINVERTING			1
#define PWM0_INVERTING              2


#endif /* MCAL_PWM0_INC_PWM0_PRIVATE_H_ */
