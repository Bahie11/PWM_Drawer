/*
 * GI_interface.h
 *
  * Created: 1/12/2024
  *  Author:Ahmed Yasser
 */

#ifndef MCAL_GI_INC_GI_INTERFACE_H_
#define MCAL_GI_INC_GI_INTERFACE_H_


              /*************** APIS PROTOTYPES ***************/

void GI_voidEnable (void);
void GI_voidDisable(void);


#endif /* MCAL_GI_INC_GI_INTERFACE_H_ */
